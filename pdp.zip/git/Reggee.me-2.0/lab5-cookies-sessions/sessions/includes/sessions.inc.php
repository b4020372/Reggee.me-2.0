<?php
////////////////////// START SESSION HERE ///////////////////////////
session_set_cookie_params(0, '/~b4020372', 'homepages.shu.ac.uk', 1, 1);
session_start();
?>