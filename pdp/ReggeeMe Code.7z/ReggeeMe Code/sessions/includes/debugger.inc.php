<div class="debug">
<h2>DEBUGGING</h2>
<?php
print_r($_SESSION);
?>
<hr>
<?php
print_r($_COOKIE);
?>
</div>