<div id="login">
<p>Welcome Admin - <a href="logic/logout.php">Log Out</a></p>
</div>